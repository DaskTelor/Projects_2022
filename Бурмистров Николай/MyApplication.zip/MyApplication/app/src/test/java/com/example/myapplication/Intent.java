package com.example.myapplication;

public class Intent {
    public Intent(MainActivity mainActivity, Class<Activity2> activity2Class) {
    }
}
